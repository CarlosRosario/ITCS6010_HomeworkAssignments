//
//  ProgramsItem.swift
//  Homework2
//
//  Created by Carlos Rosario on 7/23/16.
//  Copyright © 2016 Carlos Rosario. All rights reserved.
//

import Foundation

struct ProgramsItem {
    let id: String
    let title: String
    let additionalInfo: String
}